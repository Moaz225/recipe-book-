import React from 'react';
import { Container, Typography, Grid, Card, CardContent, CardMedia, Button } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <Container
      sx={{
        marginTop: 4,
        textAlign: 'center',
        padding: 4,
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        borderRadius: 4,
        boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)',
      }}
    >
      <Typography
        variant="h3"
        gutterBottom
        sx={{
          fontWeight: 'bold',
          color: '#1976d2',
          textShadow: '2px 2px 4px rgba(0, 0, 0, 0.2)',
        }}
      >
        Добро пожаловать в Книгу Рецептов!
      </Typography>
      <Typography
        variant="body1"
        paragraph
        sx={{
          color: '#555',
          marginBottom: 3,
          fontSize: '1.2rem',
          lineHeight: 1.6,
        }}
      >
        Здесь вы найдете лучшие рецепты для любого повода. От простых блюд для буднего дня до
        изысканных угощений для праздничного стола. Изучайте, готовьте, делитесь!
      </Typography>

      <Grid container spacing={4} sx={{ marginTop: 4 }}>
        {/* Карточка "Список рецептов" */}
        <Grid item xs={12} md={6}>
          <Card
            sx={{
              margin: 'auto',
              maxWidth: 345,
              borderRadius: 4,
              boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)',
              transition: 'transform 0.3s, box-shadow 0.3s',
              '&:hover': {
                transform: 'scale(1.05)',
                boxShadow: '0px 6px 15px rgba(0, 0, 0, 0.3)',
              },
            }}
          >
            <CardMedia
              component="img"
              height="160"
              image="/images/recipes.jpg"
              alt="Список рецептов"
              sx={{
                borderTopLeftRadius: 'inherit',
                borderTopRightRadius: 'inherit',
              }}
            />
            <CardContent>
              <Typography
                variant="h5"
                component="div"
                sx={{ fontWeight: 'bold', color: '#1976d2' }}
              >
                Список рецептов
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ marginTop: 1 }}>
                Изучите коллекцию рецептов для любого случая. Фильтруйте по категориям, добавляйте
                избранное и вдохновляйтесь!
              </Typography>
            </CardContent>
            <Button
              component={RouterLink}
              to="/recipes"
              variant="contained"
              color="primary"
              sx={{
                margin: 2,
                fontWeight: 'bold',
                borderRadius: 3,
              }}
            >
              Перейти к рецептам
            </Button>
          </Card>
        </Grid>

        {/* Карточка "Добавить рецепт" */}
        <Grid item xs={12} md={6}>
          <Card
            sx={{
              margin: 'auto',
              maxWidth: 345,
              borderRadius: 4,
              boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)',
              transition: 'transform 0.3s, box-shadow 0.3s',
              '&:hover': {
                transform: 'scale(1.05)',
                boxShadow: '0px 6px 15px rgba(0, 0, 0, 0.3)',
              },
            }}
          >
            <CardMedia
              component="img"
              height="160"
              image="/images/add_recipe.jpg"
              alt="Добавить рецепт"
              sx={{
                borderTopLeftRadius: 'inherit',
                borderTopRightRadius: 'inherit',
              }}
            />
            <CardContent>
              <Typography
                variant="h5"
                component="div"
                sx={{ fontWeight: 'bold', color: '#1976d2' }}
              >
                Добавить свой рецепт
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ marginTop: 1 }}>
                Поделитесь своими кулинарными шедеврами с другими пользователями. Добавьте описание,
                ингредиенты и пошаговую инструкцию.
              </Typography>
            </CardContent>
            <Button
              component={RouterLink}
              to="/recipes/new"
              variant="contained"
              color="primary"
              sx={{
                margin: 2,
                fontWeight: 'bold',
                borderRadius: 3,
              }}
            >
              Добавить рецепт
            </Button>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Home;
