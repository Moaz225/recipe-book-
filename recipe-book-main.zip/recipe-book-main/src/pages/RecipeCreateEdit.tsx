import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Container, Typography, TextField, Button, Box, Grid, Paper } from "@mui/material";
import axios from "axios";

interface Recipe {
  id?: number;
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
}

const RecipeCreateEdit: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [recipe, setRecipe] = useState<Recipe>({
    title: "",
    description: "",
    ingredients: "",
    instructions: "",
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (id) {
      setIsLoading(true);
      axios
        .get<Recipe>(`http://localhost:3001/recipes/${id}`)
        .then((response) => {
          setRecipe(response.data);
          setIsLoading(false);
        })
        .catch((error) => {
          console.error("Ошибка при загрузке рецепта:", error);
          setIsLoading(false);
        });
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRecipe({ ...recipe, [name]: value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (id) {
      axios
        .put(`http://localhost:3001/recipes/${id}`, recipe)
        .then(() => {
          alert("Рецепт обновлен!");
          navigate("/recipes");
        })
        .catch((error) => {
          console.error("Ошибка при обновлении рецепта:", error);
        });
    } else {
      axios
        .post("http://localhost:3001/recipes", recipe)
        .then(() => {
          alert("Рецепт создан!");
          navigate("/recipes");
        })
        .catch((error) => {
          console.error("Ошибка при создании рецепта:", error);
        });
    }
  };

  if (isLoading) {
    return (
      <Container sx={{ marginTop: 4 }}>
        <Typography variant="h5">Загрузка рецепта...</Typography>
      </Container>
    );
  }

  return (
    <Container sx={{ marginTop: 4 }}>
      <Paper
        elevation={4}
        sx={{
          padding: 4,
          backgroundColor: "rgba(255, 255, 255, 0.9)",
          borderRadius: 3,
        }}
      >
        <Typography
          variant="h3"
          gutterBottom
          sx={{
            fontWeight: "bold",
            color: "#1976d2",
            textAlign: "center",
            marginBottom: 2,
          }}
        >
          {id ? "Редактировать рецепт" : "Создать рецепт"}
        </Typography>
        <Typography variant="body1" paragraph sx={{ textAlign: "center", marginBottom: 4 }}>
          {id
            ? "Отредактируйте данные рецепта и сохраните изменения."
            : "Заполните форму для добавления нового рецепта."}
        </Typography>

        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 3,
            maxWidth: 600,
            margin: "auto",
          }}
        >
          <TextField
            label="Название рецепта"
            name="title"
            value={recipe.title}
            onChange={handleChange}
            variant="outlined"
            fullWidth
            required
          />
          <TextField
            label="Описание"
            name="description"
            value={recipe.description}
            onChange={handleChange}
            variant="outlined"
            multiline
            rows={3}
            fullWidth
            required
          />
          <TextField
            label="Ингредиенты"
            name="ingredients"
            value={recipe.ingredients}
            onChange={handleChange}
            variant="outlined"
            multiline
            rows={4}
            placeholder="Введите ингредиенты через запятую"
            fullWidth
            required
          />
          <TextField
            label="Инструкции"
            name="instructions"
            value={recipe.instructions}
            onChange={handleChange}
            variant="outlined"
            multiline
            rows={6}
            placeholder="Введите пошаговые инструкции"
            fullWidth
            required
          />
          <Box sx={{ display: "flex", justifyContent: "center", gap: 2, marginTop: 2 }}>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              sx={{ fontWeight: "bold", padding: "10px 20px" }}
            >
              Сохранить
            </Button>
            <Button
              variant="outlined"
              color="secondary"
              onClick={() => navigate("/recipes")}
              sx={{ fontWeight: "bold", padding: "10px 20px" }}
            >
              Отмена
            </Button>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
};

export default RecipeCreateEdit;
