import React, { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  Box,
  Divider,
} from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import axios from "axios";

interface Recipe {
  id: number;
  title: string;
  description: string;
}

const RecipeList: React.FC = () => {
  const [recipes, setRecipes] = useState<Recipe[]>([]);

  const fetchRecipes = () => {
    axios
      .get("http://localhost:3001/recipes")
      .then((response) => {
        setRecipes(response.data);
      })
      .catch((error) => {
        console.error("Ошибка при получении данных:", error);
      });
  };

  useEffect(() => {
    fetchRecipes();
  }, []);

  const handleDelete = (id: number) => {
    if (window.confirm("Вы уверены, что хотите удалить этот рецепт?")) {
      axios
        .delete(`http://localhost:3001/recipes/${id}`)
        .then(() => {
          setRecipes((prevRecipes) => prevRecipes.filter((recipe) => recipe.id !== id));
        })
        .catch((error) => {
          console.error("Ошибка при удалении рецепта:", error);
        });
    }
  };

  return (
    <Container sx={{ marginTop: 4 }}>
      <Typography variant="h3" gutterBottom sx={{ textAlign: "center", fontWeight: "bold" }}>
        Список рецептов
      </Typography>
      <Divider sx={{ mb: 4 }} />
      {recipes.length === 0 ? (
        <Typography variant="h5" color="text.secondary" sx={{ textAlign: "center", mt: 4 }}>
          Нет доступных рецептов. Добавьте новый рецепт, чтобы начать.
        </Typography>
      ) : (
        <Grid container spacing={4}>
          {recipes.map((recipe) => (
            <Grid item xs={12} md={6} lg={4} key={recipe.id}>
              <Card
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  height: "100%",
                  backgroundColor: "#f5f5f5",
                  boxShadow: 3,
                  transition: "transform 0.2s",
                  "&:hover": { transform: "scale(1.02)" },
                }}
              >
                <CardContent>
                  <Typography variant="h5" component="div" gutterBottom>
                    {recipe.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    {recipe.description}
                  </Typography>
                </CardContent>
                <Box sx={{ display: "flex", justifyContent: "space-between", p: 2 }}>
                  <Button
                    component={RouterLink}
                    to={`/recipes/${recipe.id}`}
                    variant="contained"
                    color="primary"
                  >
                    Подробнее
                  </Button>
                  <Button
                    variant="contained"
                    color="error"
                    onClick={() => handleDelete(recipe.id)}
                  >
                    Удалить
                  </Button>
                </Box>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
};

export default RecipeList;
