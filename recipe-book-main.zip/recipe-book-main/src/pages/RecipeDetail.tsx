import React, { useEffect, useState } from "react";
import { Container, Typography, Button, Box, Paper, Divider, Chip } from "@mui/material";
import { useParams, Link as RouterLink } from "react-router-dom";
import axios from "axios";

interface Recipe {
  id: number;
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
}

const RecipeDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    axios
      .get<Recipe>(`http://localhost:3001/recipes/${id}`)
      .then((response) => {
        setRecipe(response.data);
        setError(null);
      })
      .catch((error) => {
        console.error("Ошибка при получении данных рецепта:", error);
        setError("Рецепт не найден или произошла ошибка при загрузке.");
      });
  }, [id]);

  if (error) {
    return (
      <Container sx={{ marginTop: 4, textAlign: "center" }}>
        <Typography variant="h5" color="error" gutterBottom>
          {error}
        </Typography>
        <Button
          component={RouterLink}
          to="/recipes"
          variant="contained"
          color="primary"
          sx={{ mt: 2 }}
        >
          Вернуться к списку
        </Button>
      </Container>
    );
  }

  if (!recipe) {
    return (
      <Container sx={{ marginTop: 4, textAlign: "center" }}>
        <Typography variant="h5">Загрузка рецепта...</Typography>
      </Container>
    );
  }

  return (
    <Container sx={{ marginTop: 4, maxWidth: "lg" }}>
      <Paper
        elevation={3}
        sx={{
          padding: 4,
          borderRadius: 3,
          backgroundColor: "rgba(255, 255, 255, 0.9)",
        }}
      >
        <Box sx={{ textAlign: "center", mb: 4 }}>
          <Typography variant="h3" gutterBottom sx={{ fontWeight: "bold", color: "#1976d2" }}>
            {recipe.title}
          </Typography>
          <Typography variant="body1" paragraph sx={{ fontSize: "1.2rem", color: "#555" }}>
            {recipe.description}
          </Typography>
        </Box>

        <Divider sx={{ mb: 3 }}>
          <Chip label="Ингредиенты" color="primary" />
        </Divider>
        <Typography
          variant="body1"
          paragraph
          sx={{ whiteSpace: "pre-line", lineHeight: 1.8, fontSize: "1.1rem" }}
        >
          {recipe.ingredients}
        </Typography>

        <Divider sx={{ my: 3 }}>
          <Chip label="Инструкции" color="secondary" />
        </Divider>
        <Typography
          variant="body1"
          paragraph
          sx={{ whiteSpace: "pre-line", lineHeight: 1.8, fontSize: "1.1rem" }}
        >
          {recipe.instructions}
        </Typography>

        <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
          <Button
            component={RouterLink}
            to="/recipes"
            variant="contained"
            color="primary"
            sx={{ fontWeight: "bold", px: 4, py: 1 }}
          >
            Вернуться к списку
          </Button>
        </Box>
      </Paper>
    </Container>
  );
};

export default RecipeDetail;
