// src/components/RecipeForm.tsx
import React, { useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { Recipe } from '../api/recipesApi';
import { TextField, Button, Box } from '@mui/material';

interface RecipeFormProps {
  defaultValues?: Recipe;
  onSubmit: SubmitHandler<Recipe>;
}

const RecipeForm: React.FC<RecipeFormProps> = ({ defaultValues, onSubmit }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<Recipe>({
    defaultValues: defaultValues || {
      title: '',
      description: '',
      ingredients: '',
      instructions: '',
    },
  });

  useEffect(() => {
    if (defaultValues) {
      reset(defaultValues);
    }
  }, [defaultValues, reset]);

  return (
    <Box
      component="form"
      onSubmit={handleSubmit(onSubmit)}
      sx={{
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
        width: '100%',
        maxWidth: 600,
        margin: 'auto',
      }}
    >
      <TextField
        label="Название рецепта"
        variant="outlined"
        {...register('title', { required: 'Название рецепта обязательно' })}
        error={Boolean(errors.title)}
        helperText={errors.title?.message}
      />
      <TextField
        label="Описание"
        variant="outlined"
        {...register('description', { required: 'Описание обязательно' })}
        error={Boolean(errors.description)}
        helperText={errors.description?.message}
      />
      <TextField
        label="Ингредиенты"
        variant="outlined"
        {...register('ingredients', { required: 'Ингредиенты обязательны' })}
        error={Boolean(errors.ingredients)}
        helperText={errors.ingredients?.message}
      />
      <TextField
        label="Инструкция"
        variant="outlined"
        {...register('instructions', { required: 'Инструкция обязательна' })}
        error={Boolean(errors.instructions)}
        helperText={errors.instructions?.message}
      />
      <Button variant="contained" type="submit">
        Сохранить
      </Button>
    </Box>
  );
};

export default RecipeForm;
