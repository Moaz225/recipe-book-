import React from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

const Navbar: React.FC = () => {
  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" component={RouterLink} to="/" style={{ flexGrow: 1, color: 'inherit', textDecoration: 'none' }}>
          Книга Рецептов
        </Typography>
        <Button color="inherit" component={RouterLink} to="/">
          Главная
        </Button>
        <Button color="inherit" component={RouterLink} to="/recipes">
          Список рецептов
        </Button>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
