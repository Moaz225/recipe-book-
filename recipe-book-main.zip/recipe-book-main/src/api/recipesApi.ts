// src/api/recipesApi.ts
export interface Recipe {
    id?: number;
    title: string;
    description: string;
    ingredients: string;
    instructions: string;
  }
  
  const API_URL = 'http://localhost:3001/recipes';
  
  export const fetchRecipes = async (): Promise<Recipe[]> => {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error('Ошибка загрузки рецептов');
    }
    return response.json();
  };
  
  export const fetchRecipe = async (id: string): Promise<Recipe> => {
    const response = await fetch(`${API_URL}/${id}`);
    if (!response.ok) {
      throw new Error('Ошибка загрузки рецепта');
    }
    return response.json();
  };
  
  export const createRecipe = async (data: Recipe): Promise<Recipe> => {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!response.ok) {
      throw new Error('Ошибка создания рецепта');
    }
    return response.json();
  };
  
  export const updateRecipe = async (id: string, data: Recipe): Promise<Recipe> => {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!response.ok) {
      throw new Error('Ошибка обновления рецепта');
    }
    return response.json();
  };
  
  export const deleteRecipe = async (id: string): Promise<Recipe> => {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'DELETE'
    });
    if (!response.ok) {
      throw new Error('Ошибка удаления рецепта');
    }
    return response.json();
  };
  